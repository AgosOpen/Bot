#!/bin/bash

# ===================================================================
# Script pour lancer l'application Streamlit
# avec une version locale de Python
# ===================================================================

# Aller dans le dossier du script
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

# Chemin vers le Python embarqué ou dédié
PYTHON_PATH="$SCRIPT_DIR/python-embed/bin/python3"

echo "---------------------------------------------"
echo "Lancement de l'application Streamlit"
echo "---------------------------------------------"

"$PYTHON_PATH" -m streamlit run main.py

read -p "Appuyez sur Entrée pour fermer..."
