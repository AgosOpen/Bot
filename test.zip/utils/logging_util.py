#utils/logging_util.py

def log(message: str):
    print(f"[LOG] {message}")
