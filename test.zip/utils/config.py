#utils/config.py

# Clé d’API à remplir pour utiliser OpenAI ensuite
# utils/config.py
import os
from dotenv import load_dotenv

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENV_PATH = os.path.join(BASE_DIR, ".env")

# Charger le fichier .env s'il existe
load_dotenv(ENV_PATH)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

if not OPENAI_API_KEY:
    print("[CONFIG] Aucune clé OpenAI détectée. Configure-la via l'interface principale.")

