#pages/chat.py
import streamlit as st
import os
import sys

# Chargement du chemin du projet pour les imports internes
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.append(BASE_DIR)

from llm import rag

st.title("💬 Chatbot interne")
st.caption("Pose une question et obtiens une réponse fondée exclusivement sur les documents internes.")

# Initialisation de l'état de session
if "conversation" not in st.session_state:
    st.session_state.conversation = []

# Champ d'entrée utilisateur
question = st.text_input("Ta question :", placeholder="Ex. Quelle clause limite la responsabilité contractuelle ?",    key="chat_question_input"
)

# Bouton d'envoi
if st.button("Envoyer",  key="send_button_chat"):
    if question.strip():
        # Ajout dans l'historique local
        st.session_state.conversation.append({"role": "user", "content": question})

        # Appel de la fonction RAG (placeholder pour l’instant)
        try:
            answer = rag.get_rag_answer(question)
        except Exception as e:
            answer = f"Erreur dans le module RAG : {e}"

        st.session_state.conversation.append({"role": "assistant", "content": answer})
    else:
        st.warning("Veuillez saisir une question avant d'envoyer.")

# Affichage de l’historique
st.divider()
st.markdown("### Historique de la conversation")
for msg in st.session_state.conversation:
    role = "👤" if msg["role"] == "user" else "🤖"
    st.markdown(f"{role} **{msg['role'].capitalize()}** : {msg['content']}")

st.divider()
st.caption("Toutes les réponses sont générées à partir du corpus interne indexé (RAG).")
