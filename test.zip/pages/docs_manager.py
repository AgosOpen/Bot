#pages/docs_manager.py
import streamlit as st
import os
import sys

# Chargement du chemin du projet
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.append(BASE_DIR)

from ingestion import loader, cleaner, vectorizer
from storage import docs_store, vector_store

# Configuration de la page

st.title("📂 Gestion des documents internes")
st.caption("Upload, suppression, nettoyage et vectorisation automatique des fichiers.")

UPLOAD_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Upload de fichiers
st.subheader("Ajouter de nouveaux documents")
uploaded_files = st.file_uploader(
    "Sélectionne un ou plusieurs fichiers (.txt, .csv, .html) :", 
    type=["txt", "csv", "html"], 
    accept_multiple_files=True, 
    key="docs_selector_add"
)

if uploaded_files:
    for file in uploaded_files:
        file_path = os.path.join(UPLOAD_DIR, file.name)
        with open(file_path, "wb") as f:
            f.write(file.getbuffer())
        st.success(f"✅ {file.name} a été ajouté avec succès.")

        # Pipeline basique
        try:
            text = loader.load_file(file_path)
            cleaned = cleaner.clean_text(text)
            vectorizer.index_text(cleaned, file.name)
            st.info(f"{file.name} a été nettoyé et vectorisé.")
        except Exception as e:
            st.error(f"Erreur lors du traitement de {file.name} : {e}", key="docs_selector_treatment_error")

# --- Affichage de la liste des documents dans un expander ---
with st.expander("#Documents Indexés - Liste complète (f5 pour actualiser)"):
    if os.path.exists(UPLOAD_DIR):
        files = os.listdir(UPLOAD_DIR)
        if files:
            for f in files:
                size = os.path.getsize(os.path.join(UPLOAD_DIR, f)) / 1024
                st.write(f"• {f} ({size:.1f} Ko)")
        else:
            st.info("Aucun document enregistré pour le moment.")
    else:
        st.warning("Le répertoire de stockage n’existe pas encore.")

# Liste des documents existants pour suppression
st.subheader("Documents indexés - Suppression")
if os.path.exists(UPLOAD_DIR):
    files = os.listdir(UPLOAD_DIR)
    if files:
        selected = st.selectbox("Sélectionner un fichier à supprimer :", files)
        if st.button("Supprimer", key="docs_selector_remove"):
            os.remove(os.path.join(UPLOAD_DIR, selected))
            st.warning(f"{selected} supprimé.")
            st.rerun()
    else:
        st.write("Aucun document disponible.")
else:
    st.write("Aucun document trouvé.")

# --- Diagnostic de la base vectorielle ---
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from utils import config

VECTOR_DB_DIR = os.path.join(BASE_DIR, "data", "chroma_db")

st.subheader("🔎 Diagnostic de la base vectorielle")

try:
    embeddings = OpenAIEmbeddings(openai_api_key=config.OPENAI_API_KEY)
    vectordb = Chroma(
        persist_directory=VECTOR_DB_DIR,
        embedding_function=embeddings
    )

    # Accès direct à la collection selon version de Chroma
    try:
        count = vectordb._collection.count()
    except Exception:
        items = vectordb._collection.get(include=[])
        count = len(items.get("ids", []))

    st.info(f"Nombre total de segments indexés : **{count}**")

    if count == 0:
        st.warning("Aucun segment trouvé. Vérifie que les documents ont bien été vectorisés.")
    else:
        st.success("Base vectorielle détectée et opérationnelle.")

except Exception as e:
    st.error(f"Impossible de lire la base vectorielle : {e}")
