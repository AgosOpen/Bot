# llm/rag.py

import os
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import RetrievalQA
from utils import config

# --- Initialisation des composants RAG ---

# Chemin de la base vectorielle
VECTOR_DB_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "chroma_db")

# Initialiser la base Chroma si elle n'existe pas encore
def _get_vectorstore():
    embeddings = OpenAIEmbeddings(openai_api_key=config.OPENAI_API_KEY)
    vectordb = Chroma(
        persist_directory=VECTOR_DB_DIR,
        embedding_function=embeddings
    )
    return vectordb

# --- Fonction principale ---

def get_rag_answer(question: str) -> str:
    """
    Effectue une recherche dans la base vectorielle et génère une réponse
    fondée sur les documents internes.
    """
    try:
        vectordb = _get_vectorstore()
        retriever = vectordb.as_retriever(search_kwargs={"k": 4})

        llm = ChatOpenAI(
            openai_api_key=config.OPENAI_API_KEY,
            model="gpt-4o-mini",
            temperature=0.2
        )

        prompt = PromptTemplate(
            input_variables=["context", "question"],
            template=(
                "Tu es un assistant juridique interne d'un cabinet d'avocats. "
                "Réponds à la question suivante uniquement en te basant sur les documents fournis.\n\n"
                "Documents internes :\n{context}\n\n"
                "Question : {question}\n\n"
                "Réponse :"
            ),
        )

        chain = RetrievalQA.from_chain_type(
            llm=llm,
            retriever=retriever,
            chain_type="stuff",
            chain_type_kwargs={"prompt": prompt}
        )

        result = chain.run(question)
        return result or "Aucune réponse trouvée dans le corpus interne."

    except Exception as e:
        return f"Erreur dans le pipeline RAG : {e}"
