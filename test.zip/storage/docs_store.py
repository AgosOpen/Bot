#storage/docs_store.py
def list_documents():
    return []
