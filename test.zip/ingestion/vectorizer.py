# ingestion/vectorizer.py
"""
Module de vectorisation des documents.
Crée des embeddings à partir du texte nettoyé et les enregistre dans une base Chroma persistante.
"""

import os
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from ingestion import cleaner
from utils import config

# Dossier de persistance (même que celui utilisé par rag.py)
VECTOR_DB_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "chroma_db")
os.makedirs(VECTOR_DB_DIR, exist_ok=True)

def index_text(text: str, doc_name: str):
    """
    Nettoie, découpe en segments et indexe le texte dans Chroma.
    Chaque segment est stocké avec ses métadonnées (nom du document, position).
    """
    try:
        # Nettoyage du texte
        cleaned = cleaner.clean_text(text)

        # Tokenisation (segments d'environ 500 tokens, chevauchement de 50)
        chunks = cleaner.tokenize_text(cleaned, chunk_size=500, overlap=50)
        if not chunks:
            print(f"[Vectorizer] Aucun segment créé pour {doc_name}")
            return

        # Initialisation des embeddings et de la base Chroma
        embeddings = OpenAIEmbeddings(openai_api_key=config.OPENAI_API_KEY)
        vectordb = Chroma(
            persist_directory=VECTOR_DB_DIR,
            embedding_function=embeddings
        )

        # Ajout des documents dans la base
        metadatas = [{"source": doc_name, "chunk": i} for i in range(len(chunks))]
        vectordb.add_texts(texts=chunks, metadatas=metadatas)
        vectordb.persist()

        print(f"[Vectorizer] {len(chunks)} segments indexés pour {doc_name}")

    except Exception as e:
        print(f"[Vectorizer] Erreur lors de la vectorisation de {doc_name}: {e}")
