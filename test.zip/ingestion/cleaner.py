# ingestion/cleaner.py

import re
from bs4 import BeautifulSoup
from tiktoken import get_encoding

def clean_text(text: str) -> str:
    """
    Nettoie le texte avant vectorisation :
    - suppression des balises HTML
    - normalisation des espaces et retours à la ligne
    - suppression des caractères parasites
    """
    if not text or not isinstance(text, str):
        return ""

    # Si c'est du HTML, on enlève les balises
    if "<html" in text or "<p>" in text or "<div" in text:
        soup = BeautifulSoup(text, "html.parser")
        text = soup.get_text(separator=" ")

    # Suppression des caractères de contrôle et espaces multiples
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^\S\r\n]+", " ", text)
    text = text.replace("\xa0", " ").strip()

    # Suppression des entêtes de tableurs ou codes CSV
    text = re.sub(r"(;|,){2,}", " ", text)

    return text


def tokenize_text(text: str, chunk_size: int = 500, overlap: int = 50):
    """
    Découpe le texte nettoyé en segments de tokens pour la vectorisation.
    Utilise le tokenizer 'cl100k_base' compatible avec les modèles GPT.
    """
    encoding = get_encoding("cl100k_base")
    tokens = encoding.encode(text)
    total_tokens = len(tokens)
    
    chunks = []
    start = 0
    while start < total_tokens:
        end = min(start + chunk_size, total_tokens)
        chunk = tokens[start:end]
        chunk_text = encoding.decode(chunk)
        chunks.append(chunk_text)
        start += chunk_size - overlap

    return chunks
